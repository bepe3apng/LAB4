#include <windows.h> //Подключение Windows API.
#include <gl/gl.h> //Подключение OpenGL.
#include <math.h> //Подключение математических функций.
#include <iostream> //Подключение стандартного ввода/вывода.
#include "src/main.h" //Подключение заголовочных файлов проекта.
#include "src/menu.h"
#include "src/textur.h"


using namespace std;  //Использование пространства имен std для упрощения записи.

LRESULT CALLBACK WindowProc(HWND, UINT, WPARAM, LPARAM); //Объявление прототипов функций: WindowProc, EnableOpenGL, DisableOpenGL.
void EnableOpenGL(HWND hwnd, HDC*, HGLRC*);
void DisableOpenGL(HWND, HDC, HGLRC);

int vx = 0; //Глобальная переменная vx инициализирована нулем.

int WINAPI WinMain(HINSTANCE hInstance, //Основная функция, с которой начинается выполнение программы в Windows.
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{
    WNDCLASSEX wcex; //Объявление переменных: WNDCLASSEX wcex (описание окна)
    HWND hwnd; //HWND hwnd (дескриптор окна)
    HDC hDC; //HDC hDC (контекст устройства)
    HGLRC hRC; //HGLRC hRC (контекст рендеринга)
    MSG msg; //MSG msg (сообщения окна)
    BOOL bQuit = FALSE; //BOOL bQuit (флаг выхода)

    wcex.cbSize = sizeof(WNDCLASSEX); //Размер структуры.
    wcex.style = CS_OWNDC; //Стиль класса окна (CS_OWNDC - уникальный контекст устройства для каждого окна).
    wcex.lpfnWndProc = WindowProc; //Указатель на функцию обработки сообщений окна.
    wcex.cbClsExtra = 0; //Дополнительные байты в классе и экземпляре окна.
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance; //Дескриптор экземпляра приложения.
    wcex.hIcon = LoadIcon(NULL, IDI_APPLICATION); //Иконки окна.
    wcex.hCursor = LoadCursor(NULL, IDC_ARROW); //Курсор окна.
    wcex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH); //Фон окна (черный).
    wcex.lpszMenuName = NULL; //Имя меню.
    wcex.lpszClassName = "GLSample"; //Имя класса окна.
    wcex.hIconSm = LoadIcon(NULL, IDI_APPLICATION); //Иконки окна.

    if (!RegisterClassEx(&wcex)) //Регистрация класса окна с помощью RegisterClassEx.
        return 0;

    hwnd = CreateWindowEx(0,
                          "GLSample", //Имя класса окна.
                          "Osharov Game", //Заголовок окна.
                          WS_OVERLAPPEDWINDOW, //Стиль окна.
                          CW_USEDEFAULT, //Позиция и размер окна (используются значения по умолчанию).
                          CW_USEDEFAULT,
                          width,
                          height,
                          NULL,
                          NULL,
                          hInstance, //Дескриптор экземпляра приложения.
                          NULL);

    ShowWindow(hwnd, nCmdShow); //Отображение окна с помощью ShowWindow.
    EnableOpenGL(hwnd, &hDC, &hRC); //Инициализация OpenGL с помощью EnableOpenGL.

    Main_Init(); //Вызов функций инициализации Main_Init и Menu_Init.
    Menu_Init();
    RECT rct; //Создание переменной с координатами прямоуголника.
    GetClientRect(hwnd, &rct);  //Получение текущих координат окна.
    glOrtho(0,rct.right,0,rct.bottom,1,-1);  //Выставляем их как координаты окна.

    while (!bQuit)
    {
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) //Проверка наличия сообщений в очереди.
        {
            if (msg.message == WM_QUIT)
            {
                bQuit = TRUE;
            }
            else
            {
                TranslateMessage(&msg); //Обработка сообщений.
                DispatchMessage(&msg);
            }
        }
        else
        {
            glClearColor(0.8f, 0.5f, 0.3f, 0.5f); //Очищение экрана с помощью glClearColor и glClear.
            glClear(GL_COLOR_BUFFER_BIT);

            Show_Background(background); //Вызов функций для отображения фона и героя.
            if (gameState == 1)
            {
                Hero_Move(&pers);

                Hero_Show(&pers);
            };

            glPushMatrix(); //Сохранение и восстановление матрицы с помощью glPushMatrix и glPopMatrix.
            glLoadIdentity();
            glOrtho(0,rct.right,rct.bottom, 0,1,-1);
            Menu_ShowMenu(); //Отображение меню с помощью Menu_ShowMenu.
            glPopMatrix();

            SwapBuffers(hDC); //Обновление экрана с помощью SwapBuffers.
            Sleep (1); //Задержка выполнения с помощью Sleep.
        }
    }

    DisableOpenGL(hwnd, hDC, hRC); //Отключение OpenGL с помощью DisableOpenGL.
    DestroyWindow(hwnd); //Уничтожение окна с помощью DestroyWindow.
    return msg.wParam; //Возврат кода завершения программы.
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
    case WM_CLOSE: //Сообщение о закрытии окна.
        PostQuitMessage(0);
        break;

    case WM_DESTROY: //Сообщение об уничтожении окна.
        return 0;

    case WM_MOUSEMOVE: //Движение мыши.
        Menu_MouseMove(LOWORD(lParam), HIWORD(lParam));
        break;

    case WM_LBUTTONDOWN: //Нажатие левой кнопки мыши.
        MouseDown();
        break;

    case WM_LBUTTONUP: //Отпускание левой кнопки мыши.
        Menu_MouseUp();
        break;

    case WM_KEYDOWN: //Нажатие клавиши на клавиатуре.
    {
        switch (wParam)
        {
        case VK_ESCAPE: //Нажатие клавиши Escape.
            PostQuitMessage(0);
            break;

        case VK_RETURN: //Нажатие клавиши Enter.
            gameState=1;
            break;
        }
    }
    break;

    default:
        return DefWindowProc(hwnd, uMsg, wParam, lParam); //Обработка других сообщений с помощью DefWindowProc.
    }
    return 0;
}

void EnableOpenGL(HWND hwnd, HDC* hDC, HGLRC* hRC) //Инициализация OpenGL.
{
    PIXELFORMATDESCRIPTOR pfd;
    int iFormat;
    *hDC = GetDC(hwnd);
    ZeroMemory(&pfd, sizeof(pfd));

    pfd.nSize = sizeof(pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW |
                  PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 24;
    pfd.cDepthBits = 16;
    pfd.iLayerType = PFD_MAIN_PLANE;

    iFormat = ChoosePixelFormat(*hDC, &pfd); //Настройка контекста устройства и пиксельного формата.
    SetPixelFormat(*hDC, iFormat, &pfd);
    *hRC = wglCreateContext(*hDC); //Создание контекста рендеринга и установка текущего контекста.
    wglMakeCurrent(*hDC, *hRC);
}

void DisableOpenGL (HWND hwnd, HDC hDC, HGLRC hRC) //Завершение работы с OpenGL.
{
    wglMakeCurrent(NULL, NULL); //Сброс и удаление контекста рендеринга.
    wglDeleteContext(hRC);
    ReleaseDC(hwnd, hDC); //Освобождение контекста устройства.
}

